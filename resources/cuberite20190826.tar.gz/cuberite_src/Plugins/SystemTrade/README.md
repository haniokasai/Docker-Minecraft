# SystemTrade
A plugin for Cuberite 
By this plugin player can buy Item for system or sale to system  
Need plugin [Coin](https://github.com/dustinengle/coin)
# command
`/systrade <buy|sale>` To open trade window  
# Note
Left click to buy or sale item.  
Right click to show price and trade detail
