SELECT `MinX`, `MaxX`, `MinY`, `MaxY`, `MinZ`, `MaxZ` 
FROM "PlayerSelection"
WHERE uuid = $playeruuid