# CuberiteMaze
A Cuberite plugin that generates random mazes using Kruskal's algorithm
