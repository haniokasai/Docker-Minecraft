g_PluginInfo =
{
	Name = "Auto Replant",
	Version = 0.1,
	Date = "2015-06-25",
	Description = "This plugin makes right-clicking a fully-grown crop harvest and automatically replant it.",
	
	-- The following members will be documented in greater detail later:
	AdditionalInfo = {},
	Commands = {},
	ConsoleCommands = {},
	Permissions = {},
}