SkyBlock V3
===========

SkyBlock lua plugin for Cuberite, the c++ minecraft server.

For Installation
=======
1) Download the file [SkyBlock.zip](https://github.com/Seadragon91/SkyBlock/archive/master.zip)  
2) Change the folder name to SkyBlock and add it to the folder Plugins  
3) In the settings.ini, add this line `Plugin=SkyBlock` to the section [Plugins]  
4) In the settings.ini, add this line `World=skyblock` to the section [Worlds]  
5) Start server and happy playing :-)  


For Updating
======
Use this step only, if you want to upgrade from a previous version  
1) **Make an Backup from the current SkyBlock plugin and the skyblock world**  
2) Download the [SkyBlock.zip](https://github.com/Seadragon91/SkyBlock/archive/master.zip) and extract it   
3) Copy the folder code and the file SkyBlock.lua into the plugin folder of SkyBlock  
