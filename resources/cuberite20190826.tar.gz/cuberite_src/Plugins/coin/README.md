# coin
A Cuberite Economy Plugin

Check out the API for the plugin interface.  There is also the ability to send "Coin".

More information coming soon...
