
PLUGIN = 'Coin'
VERSION = 1