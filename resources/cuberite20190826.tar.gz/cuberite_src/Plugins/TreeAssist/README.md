# TreeAssist
A plugin for Cuberite 
Modify form [TreeAssist](https://github.com/NiLSPACE/TreeAssist) Author: NiLSPACE 

# How to use
1.Please make a directory named 'TreeAssist' in 'Plugins' folder, then put file 'TreeAssist.lua' in this folder.  
2.Add one line 'Plugin=TreeAssist' to settings.ini file in section '[Plugins]'  
