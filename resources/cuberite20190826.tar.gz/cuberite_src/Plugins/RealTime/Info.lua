g_PluginInfo =
{
	Name = "RealTime",
	Date = "2016-01-28",
	Description = "sync server time with ingame time",

	-- The following members will be documented in greater detail later:
	AdditionalInfo = {},
	Commands = {},
	ConsoleCommands = {},
	Permissions = {},
}
