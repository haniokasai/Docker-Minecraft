# RealTime
Cuberite Plugin to Sync your local PC time to Ingame Time

Installation:
Just enable the Plugin and it should sync the ingame Time
