Plugin that adds weapons to a Cuberite server. Currently available weapons are Anvil Dropper, Lightning Stick, Nuker and Sniper.

# Commands

### General
| Command | Permission | Description |
| ------- | ---------- | ----------- |
|/weapons | weapons.weapons | Gives you a weapon|



# Permissions
| Permissions | Description | Commands | Recommended groups |
| ----------- | ----------- | -------- | ------------------ |
| weapons.weapons |  | `/weapons` |  |
