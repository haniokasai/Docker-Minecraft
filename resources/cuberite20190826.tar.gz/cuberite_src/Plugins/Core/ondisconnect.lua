function OnDisconnect(a_Player)
	WEBLOGINFO(a_Player:GetName() .. " has left the game")
end