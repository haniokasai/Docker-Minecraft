function HandleRequest_ManageServer( Request )
	local Content = ""
	if (Request.PostParams["RestartServer"] ~= nil) then
		cRoot:Get():QueueExecuteConsoleCommand("restart")
	elseif (Request.PostParams["ReloadServer"] ~= nil) then
		cRoot:Get():GetPluginManager():ReloadPlugins()
	elseif (Request.PostParams["StopServer"] ~= nil) then
		cRoot:Get():QueueExecuteConsoleCommand("stop")
	elseif (Request.PostParams["WorldSaveAllChunks"] ~= nil) then
		cRoot:Get():GetWorld(Request.PostParams["WorldSaveAllChunks"]):QueueSaveAllChunks()
	end
	Content = Content .. [[
	<form method="POST">
	<table>
	<th colspan="2">サーバー管理</th>
	<tr><td><input type="submit" value="サーバー再起動" name="RestartServer"></td></tr>
	<tr><td><input type="submit" value="サーバー再読み込み" name="ReloadServer"></td></tr>
	<tr><td><input type="submit" value="サーバー停止" name="StopServer"></td></tr>
	</th>
	</table>
	<br />
	<table>
	<th colspan="2">ワールド管理</th>
	]]
	local LoopWorlds = function( World )
		Content = Content .. [[
		<tr><td><input type="submit" value="]] .. World:GetName()  .. [[" name="WorldSaveAllChunks"> のすべてのチャンクの保存 ]] .. [[</td></tr>

		]]
	end
	cRoot:Get():ForEachWorld( LoopWorlds )
	Content = Content .. "</th></table>"

	return Content
end
